if getgenv().squid_game_executed then
    error("Shrimp Game script is already running")
    return
else
    getgenv().squid_game_executed = true
end

repeat task.wait() until game:IsLoaded()
if game.PlaceId == 7606602544 or game.PlaceId == 7606564092 or game.PlaceId == 130207304381701 then
    version = game:HttpGet("https://pastebin.com/raw/PT1wA6si")
    if not isfile("squid_game.lua") then
        writefile("squid_game.lua", game:HttpGet("https://pastebin.com/raw/vxQVYwhA"))
    end
    if not isfile("squid_game_version.txt") then
        writefile("squid_game_version.txt", version)
    end
    if version ~= "3.0.11" then
        delfile("squid_game.lua")
        delfile("squid_game_version.txt")
        writefile("squid_game.lua", game:HttpGet("https://pastebin.com/raw/vxQVYwhA"))
        writefile("squid_game_version.txt", version)
    end
    queue_on_teleport("task.wait(5)\n" .. readfile("squid_game.lua"))
end

local engine = loadstring(game:HttpGet("https://pastebin.com/raw/y6LMLtit"))()

if game.PlaceId == 7606602544 then
    local function notify(title, message)
        game:GetService("StarterGui"):SetCore("SendNotification", {
            Title = title,
            Text = message
        })
    end

    local hide_cutscenes_state = true
    local auto_room_state = false
    local notifications_state = true
    local teleport_to_another = true
    local cookie_shape_state = false
    local cookie_shape_value = 2
    local skip_dalgona = false
    local six_legged_pentathlon = false
    local pentathlon_skip = false

    -- crashes on swift unless done this way... don't know why
    getrenv().pentathlon_s = function(args)
        if args[2] == "Start Game" then
            six_legged_pentathlon = true
            spawn(function()
                while task.wait() and six_legged_pentathlon do
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Start Minigame", 1)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Minigame Complete", "Ddakji")
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Throw Envelope", 60)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Start Minigame", 2)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Throw Stone", 60)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Minigame Complete", "Biseokchigi")
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Start Minigame", 3)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Minigame Complete", "Gonggi")
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Start Minigame", 4)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Throw Spinning Top", 60)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Start Minigame", 5)
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Minigame Complete", "Jegi")
                    game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Pentathlon Complete")
                end
            end)
        elseif args[2] == "Stop Game" then
            six_legged_pentathlon = false
            game.Players.LocalPlayer.Character.ChildAdded:Connect(function(child)
                if child.Name == "Ornament" or child.Name == "Body" then
                    spawn(function()
                        child:Destroy()
                    end)
                    for i,v in pairs(game.Players.LocalPlayer.Character.Humanoid:GetPlayingAnimationTracks()) do
                        v:Stop()
                    end
                end
            end)
            workspace.Pentathlon.ChildAdded:Connect(function(child)
                if string.find(child.Name, game.Players.LocalPlayer.Name) then
                    spawn(function()
                        child:Destroy()
                    end)
                end
            end)
        end
    end

    for i,v in pairs(getconnections(game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent.OnClientEvent)) do
        if islclosure(v.Function) then
            local old; old = hookfunction(v.Function, function(...)
                local args = { ... }
                if (args[2] == "Cutscene" or args[2] == "Start Cutscene") then
                    if hide_cutscenes_state then
                        return nil
                    end
                end
                if args[1] == "Honeycomb" then
                    if args[2] == "Play" and skip_dalgona then
                        game:GetService("ReplicatedStorage").Remotes.Events.EffectsEvent:FireServer("Success", true)
                        for i,v in pairs(game.Players.LocalPlayer.Character.Humanoid:GetPlayingAnimationTracks()) do
                            v:Stop()
                        end
                        return nil
                    elseif args[2] == "Selection" then
                        if cookie_shape_state then
                            args[3] = cookie_shape_value
                        end
                        if notifications_state then
                            if args[3] == 1 then
                                notify("Honeycombs", "You just got a circle.")
                            elseif args[3] == 2 then
                                notify("Honeycombs", "You just got a triangle.")
                            elseif args[3] == 3 then
                                notify("Honeycombs", "You just got a star.")
                            elseif args[3] == 4 then
                                notify("Honeycombs", "You just got an umbrella.")
                            elseif args[3] == 5 then
                                notify("Honeycombs", "You just got the Mona Lisa. Good luck")
                            end
                        end
                    end
                elseif args[1] == "Mingle" then
                    if args[2] == "TurnOnDoorLights" and auto_room_state and teleport_to_another then
                        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = args[3].BoundingBox.CFrame
                        teleport_to_another = false
                    elseif args[2] == "TurnOffDoorLights" then
                        teleport_to_another = true
                    end
                elseif args[1] == "Pentathlon" and pentathlon_skip then
                    pentathlon_s(args)
                    if args[2] == "Update Minigame" then
                        return nil
                    end
                end
                return old(unpack(args))
            end)
        end
    end

    local window = engine.new({
        text = "Shrimp Game",
        size = Vector2.new(300, 480),
    })

    window.open()

    local main_tab = window.new({
        text = "Games"
    })

    local label1 = main_tab.new("label", {
        text = "Red Light Green Light"
    })

    local rlgl_win = main_tab.new("button", {
        text = "Win Red Light Green Light"
    })
    rlgl_win.event:Connect(function()
        if string.find(identifyexecutor(), "Swift") then
            firetouchinterest(game.Players.LocalPlayer.Character.HumanoidRootPart, workspace.LightGameBlocker, 0)
            firetouchinterest(game.Players.LocalPlayer.Character.HumanoidRootPart, workspace.LightGameBlocker, 1)
        else
            firetouchinterest(workspace.LightGameBlocker, game.Players.LocalPlayer.Character.HumanoidRootPart, 0)
            firetouchinterest(workspace.LightGameBlocker, game.Players.LocalPlayer.Character.HumanoidRootPart, 1)
        end
    end)

    local label2 = main_tab.new("label", {
        text = "Sugar Honeycombs"
    })

    local skip_dalgona_switch = main_tab.new("switch", {
        text = "Skip All (before start)"
    })
    skip_dalgona_switch.event:Connect(function(state)
        skip_dalgona = state
    end)

    local change_cookie_switch = main_tab.new("switch", {
        text = "Change Cookie Shape"
    })
    change_cookie_switch.event:Connect(function(state)
        cookie_shape_state = state
    end)

    local convert_shape_table = {
        Circle = 1,
        Triangle = 2,
        Star = 3,
        Umbrella = 4,
        ["Mona Lisa"] = 5
    }
    local change_cookie_dropdown = main_tab.new("dropdown", {
        text = "Shape"
    })
    change_cookie_dropdown.event:Connect(function(name)
        cookie_shape_value = convert_shape_table[name]
    end)
    change_cookie_dropdown.new("Circle")
    change_cookie_dropdown.new("Triangle")
    change_cookie_dropdown.new("Star")
    change_cookie_dropdown.new("Umbrella")
    change_cookie_dropdown.new("Mona Lisa")

    local label3 = main_tab.new("label", {
        text = "Mingle"
    })

    local auto_room_switch = main_tab.new("switch", {
        text = "Auto Room"
    })
    auto_room_switch.event:Connect(function(state)
        auto_room_state = state
    end)

    local label4 = main_tab.new("label", {
        text = "Lights Out"
    })

    local knife_aura_state = false

    local knife_aura = main_tab.new("switch", {
        text = "Knife Aura"
    })
    knife_aura.event:Connect(function(state)
        knife_aura_state = state
        while task.wait() and knife_aura_state do
            for i,v in pairs(game.Players:GetChildren()) do
                if v.Name ~= game.Players.LocalPlayer.Name then
                    if workspace:FindFirstChild(v.Name) then
                        eRoot = v.Character:FindFirstChild("HumanoidRootPart")
                        if eRoot then
                            hRoot = game.Players.LocalPlayer.Character.HumanoidRootPart
                            if (eRoot.Position - hRoot.Position).magnitude < 10 then
                                game:GetService("ReplicatedStorage").Remotes.Events.Knife:FireServer(v.Character)
                            end
                        end
                    end
                end
            end
        end
    end)

    local label5 = main_tab.new("label", {
        text = "Pentathlon"
    })

    local skip_pentathlon_switch = main_tab.new("switch", {
        text = "Skip All (before start)"
    })
    skip_pentathlon_switch.event:Connect(function(state)
        pentathlon_skip = state
    end)

    local label6 = main_tab.new("label", {
        text = "Tug of War"
    })

    local pull_rope_state = false

    local pull_rope = main_tab.new("switch", {
        text = "Loop Pull Rope"
    })
    pull_rope.event:Connect(function(state)
        pull_rope_state = state
        while task.wait() and pull_rope_state do
            game:GetService("ReplicatedStorage").Remotes.Events.PullRope:FireServer()
        end
    end)

    local label7 = main_tab.new("label", {
        text = "Stepping Stones (Glass Tester required)"
    })

    local get_steps = main_tab.new("button", {
        text = "Remove Unsafe Steps"
    })
    get_steps.event:Connect(function()
        for i,v in pairs(workspace.SteppingStones.Tiles:GetChildren()) do
            for i = 1, 5 do
                spawn(function()
                    pcall(function()
                        local step = v:GetChildren()[1]
                        local req = game:GetService("ReplicatedStorage").Remotes.Functions.GlassTester:InvokeServer(step)
                        if req == "safe" then
                            local ostep = v:GetChildren()[2]
                            ostep:Destroy()
                        elseif req == "unsafe" then
                            step:Destroy()
                        end
                    end)
                end)
            end
        end
    end)
    local win_steps = main_tab.new("button", {
        text = "Win Steps (use after remove)"
    })
    win_steps.event:Connect(function()
        for i,v in pairs(workspace.SteppingStones.Tiles:GetChildren()) do
            if #v:GetChildren() == 1 then
                step = v:GetChildren()[1]
                firetouchinterest(game.Players.LocalPlayer.Character.HumanoidRootPart, step, 0)
                firetouchinterest(game.Players.LocalPlayer.Character.HumanoidRootPart, step, 1)
            end
            task.wait()
        end
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = workspace.Maps["Stepping Stones"].End.Build.SteppingStonesGate.Barrier.CFrame + Vector3.new(-10, -6, 0)
    end)

    local label8 = main_tab.new("label", {
        text = "Squid Game"
    })

    local punch_aura_state = false

    local punch_aura = main_tab.new("switch", {
        text = "Punch Aura"
    })
    punch_aura.event:Connect(function(state)
        punch_aura_state = state
        while task.wait() and punch_aura_state do
            for i,v in pairs(game.Players:GetChildren()) do
                if v.Name ~= game.Players.LocalPlayer.Name then
                    if workspace:FindFirstChild(v.Name) then
                        eRoot = v.Character:FindFirstChild("HumanoidRootPart")
                        if eRoot then
                            hRoot = game.Players.LocalPlayer.Character.HumanoidRootPart
                            if (eRoot.Position - hRoot.Position).magnitude < 10 then
                                game:GetService("ReplicatedStorage").Remotes.Events.Punch:FireServer(v.Character)
                            end
                        end
                    end
                end
            end
        end
    end)

    local player_tab = window.new({
        text = "Player"
    })

    local walk_speed_state = false
    local walk_speed_value = 14

    game.Players.LocalPlayer.Character.Humanoid:GetPropertyChangedSignal("WalkSpeed"):Connect(function()
        if walk_speed_state then
            game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = walk_speed_value
        end
    end)

    local walk_speed_switch = player_tab.new("switch", {
        text = "Enable Walk Speed"
    })
    walk_speed_switch.event:Connect(function(state)
        walk_speed_state = state
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = walk_speed_value
    end)

    local walk_speed = player_tab.new("slider", {
        text = "Speed",
        size = 200,
        min = 14,
        max = 100
    })
    walk_speed.event:Connect(function(ws)
        walk_speed_value = ws
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = WS
    end)

    local jump_power_state = false
    local jump_power_value = 50

    game.Players.LocalPlayer.Character.Humanoid:GetPropertyChangedSignal("JumpPower"):Connect(function()
        if jump_power_state then
            game.Players.LocalPlayer.Character.Humanoid.JumpPower = jump_power_value
        end
    end)

    local jump_power_switch = player_tab.new("switch", {
        text = "Enable Jump Power"
    })
    jump_power_switch.event:Connect(function(state)
        jump_power_state = state
        game.Players.LocalPlayer.Character.Humanoid.JumpPower = jump_power_value
    end)

    local jump_power = player_tab.new("slider", {
        text = "Jump Power",
        size = 200,
        min = 50,
        max = 100
    })
    jump_power.event:Connect(function(jp)
        jump_power_value = jp
        game.Players.LocalPlayer.Character.Humanoid.JumpPower = jump_power_value
    end)

    local convert_teleport_table = {
        Lobby = CFrame.new(-138, 7, -59),
        ["Red Light Green Light"] = CFrame.new(142, 4, 164),
        Honeycombs = CFrame.new(-428, 4, 88),
        Mingle = CFrame.new(1160, 8, -81),
        ["Tug of War"] = CFrame.new(-1772, -52, -64),
        ["Stepping Stones"] = CFrame.new(775, 52, -1852),
        ["Squid Game"] = CFrame.new(336, 4, 255),
        Marbles = CFrame.new(-1596, -70, 773),
        ["Six Legged Pentathlon"] = CFrame.new(-167, 8, -565),
        ["Piggy Bank"] = CFrame.new(-77, 20, -58)
    }
    local convert_teleport_dropdown = player_tab.new("dropdown", {
        text = "Teleports"
    })
    convert_teleport_dropdown.event:Connect(function(name)
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = convert_teleport_table[name]
    end)
    convert_teleport_dropdown.new("Lobby")
    convert_teleport_dropdown.new("Red Light Green Light")
    convert_teleport_dropdown.new("Honeycombs")
    convert_teleport_dropdown.new("Mingle")
    convert_teleport_dropdown.new("Tug of War")
    convert_teleport_dropdown.new("Stepping Stones")
    convert_teleport_dropdown.new("Squid Game")
    convert_teleport_dropdown.new("Marbles")
    convert_teleport_dropdown.new("Six Legged Pentathlon")
    convert_teleport_dropdown.new("Piggy Bank")

    local visual_tab = window.new({
        text = "Visual"
    })

    local hide_cutscenes = visual_tab.new("switch", {
        text = "Hide Cutscenes"
    })
    hide_cutscenes.event:Connect(function(state)
        hide_cutscenes_state = state
    end)
    hide_cutscenes:set(true)

    local notifications_switch = visual_tab.new("switch", {
        text = "Show Game Notifications"
    })
    notifications_switch.event:Connect(function(state)
        notifications_state = state
    end)
    notifications_switch:set(true)

    local stop_animations = visual_tab.new("button", {
        text = "Stop Animations"
    })
    stop_animations.event:Connect(function()
        for i,v in pairs(game.Players.LocalPlayer.Character.Humanoid:GetPlayingAnimationTracks()) do
            v:Stop()
        end
    end)

    local info_tab = window.new({
        text = "Info"
    })

    local label9 = info_tab.new("label", {
        text = "Made by usamiername"
    })

    local label10 = info_tab.new("label", {
        text = "Version 3.0.11 (01/18/2025)"
    })

    main_tab.show()
elseif game.PlaceId == 7606564092 or game.PlaceId == 130207304381701 then
    local window = engine.new({
        text = "Shrimp Game",
        size = Vector2.new(200, 100),
    })

    window.open()

    local main_tab = window.new({
        text = "Lobby"
    })

    local label1 = main_tab.new("label", {
        text = "\nWaiting for game..."
    })
    
end